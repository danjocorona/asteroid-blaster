import pygame
import sys
import random
from math import dist
from game.player import Player
from game.bullet import Bullet
from game.asteroid import Asteroid

# For browser focus detection
try:
    from js import window
    web_mode = True
except ImportError:
    web_mode = False

# Setup
pygame.init()
WIDTH, HEIGHT = 1600, 1200
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Asteroids Blaster")
clock = pygame.time.Clock()

# Load assets
player_img = pygame.image.load("assets/images/player.png").convert_alpha()
bullet_img = pygame.image.load("assets/images/laserGreen.png").convert_alpha()
asteroid_img = pygame.image.load("assets/images/meteorGrey_big1.png").convert_alpha()
background_raw = pygame.image.load("assets/images/background.png").convert()
background = pygame.transform.scale(background_raw, (WIDTH, HEIGHT))
laser_sound = pygame.mixer.Sound("assets/sounds/sfx_laser1.ogg")
lose_sound = pygame.mixer.Sound("assets/sounds/sfx_lose.ogg")
explosion_large = pygame.mixer.Sound("assets/sounds/impactMetal_000.ogg")
explosion_medium = pygame.mixer.Sound("assets/sounds/impactMetal_002.ogg")
explosion_small = pygame.mixer.Sound("assets/sounds/impactMetal_001.ogg")
menu_music = pygame.mixer.Sound("assets/sounds/menu.ogg")

# Background music
pygame.mixer.music.load("assets/sounds/space.ogg")

# Browser focus event handlers (for web only)
if web_mode:
    def on_focus(_=None):
        pygame.mixer.music.unpause()
        if not game_started and not game_over:
            menu_music.play(-1)

    def on_blur(_=None):
        pygame.mixer.music.pause()
        menu_music.stop()

    window.addEventListener("focus", on_focus)
    window.addEventListener("blur", on_blur)

# Fonts
font_large = pygame.font.Font(None, 100)
font_medium = pygame.font.Font(None, 72)

# Initialize game state
def reset_game():
    player = Player(WIDTH // 2, HEIGHT // 2, player_img)
    bullets = []
    asteroids = [
        Asteroid(random.randint(0, WIDTH), random.randint(0, HEIGHT), random.choice([64, 48, 32]),
                 asteroid_img, WIDTH, HEIGHT)
        for _ in range(5)
    ]
    return player, bullets, asteroids, 0

player, bullets, asteroids, score = reset_game()
game_over = False
game_started = False  # Start menu state
menu_music.play(-1)  # Loop menu music

# Asteroid spawn timer
SPAWN_ASTEROID = pygame.USEREVENT + 1
pygame.time.set_timer(SPAWN_ASTEROID, 3000)

# Game loop
running = True
while running:
    clock.tick(60)
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if not game_started:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                game_started = True
                menu_music.stop()
                pygame.mixer.music.play(-1)

        elif not game_over:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                angle = player.get_angle()
                x, y = player.get_gun_position()
                bullets.append(Bullet(x, y, angle, bullet_img, player.dx, player.dy))
                laser_sound.play()
            elif event.type == SPAWN_ASTEROID:
                x = random.choice([0, WIDTH])
                y = random.randint(0, HEIGHT)
                size = random.choice([64, 48, 32])
                asteroids.append(Asteroid(x, y, size, asteroid_img, WIDTH, HEIGHT))

        elif game_over:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                player, bullets, asteroids, score = reset_game()
                game_over = False
                pygame.mixer.music.play(-1)

    # Update and draw
    screen.blit(background, (0, 0))

    if not game_started:
        title = font_large.render("Asteroids Blaster", True, (255, 255, 255))
        prompt = font_medium.render("Press ENTER to Start", True, (200, 200, 200))
        screen.blit(title, (WIDTH // 2 - title.get_width() // 2, HEIGHT // 2 - 100))
        screen.blit(prompt, (WIDTH // 2 - prompt.get_width() // 2, HEIGHT // 2 + 20))

    elif not game_over:
        player.update(keys, WIDTH, HEIGHT)
        for bullet in bullets:
            bullet.update()
        for asteroid in asteroids:
            asteroid.update()

        # Player vs asteroid collision
        for asteroid in asteroids:
            pc, pr = player.get_collision_circle()
            ac, ar = asteroid.get_collision_circle()
            if dist(pc, ac) < pr + ar:
                game_over = True
                pygame.mixer.music.stop()
                lose_sound.play()
                break

        # Bullet vs asteroid collision
        new_asteroids = []
        bullets_to_remove = []
        asteroids_to_remove = []

        for bullet in bullets:
            for asteroid in asteroids:
                if bullet.rect.colliderect(asteroid.rect):
                    bullets_to_remove.append(bullet)
                    asteroids_to_remove.append(asteroid)
                    new_asteroids.extend(asteroid.split())

                    if asteroid.size >= 60:
                        score += 100
                        explosion_large.play()
                    elif asteroid.size >= 45:
                        score += 50
                        explosion_medium.play()
                    else:
                        score += 25
                        explosion_small.play()
                    break

        for bullet in bullets_to_remove:
            if bullet in bullets:
                bullets.remove(bullet)
        for asteroid in asteroids_to_remove:
            if asteroid in asteroids:
                asteroids.remove(asteroid)

        asteroids.extend(new_asteroids)
        bullets = [b for b in bullets if not b.is_off_screen(WIDTH, HEIGHT)]

        # Draw
        player.draw(screen)
        for bullet in bullets:
            bullet.draw(screen)
        for asteroid in asteroids:
            asteroid.draw(screen)

        score_text = font_medium.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_text, (20, 20))

    else:
        text = font_medium.render("GAME OVER - Press R to Restart", True, (255, 0, 0))
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2))

        score_text = font_medium.render(f"Final Score: {score}", True, (255, 255, 255))
        screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 + 60))

    pygame.display.flip()