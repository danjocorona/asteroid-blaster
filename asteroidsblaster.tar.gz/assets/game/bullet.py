import pygame
import math

class Bullet:
    def __init__(self, x, y, angle, image, parent_dx=0, parent_dy=0):
        self.original_image = image
        self.angle = angle
        self.image = pygame.transform.rotate(self.original_image, -self.angle)
        self.rect = self.image.get_rect(center=(x, y))
        self.pos = pygame.Vector2(x, y)

        speed = 10
        rad = math.radians(self.angle)
        self.velocity = pygame.Vector2(
            math.sin(rad) * speed + parent_dx,
            -math.cos(rad) * speed + parent_dy
        )

    def update(self):
        self.pos += self.velocity
        self.rect.center = self.pos

    def is_off_screen(self, screen_width, screen_height):
        return not (0 <= self.pos.x <= screen_width and 0 <= self.pos.y <= screen_height)

    def draw(self, surface):
        rotated = pygame.transform.rotate(self.original_image, -self.angle)
        rotated_rect = rotated.get_rect(center=self.rect.center)
        surface.blit(rotated, rotated_rect)