import pygame
import random

class Asteroid:
    def __init__(self, x, y, size, image, screen_width, screen_height):
        self.image_original = pygame.transform.scale(image, (size, size))
        self.image = self.image_original.copy()
        self.rect = self.image.get_rect(center=(x, y))
        self.pos = pygame.Vector2(x, y)
        self.size = size
        self.screen_width = screen_width
        self.screen_height = screen_height

        angle = random.uniform(0, 360)
        speed = random.uniform(1.0, 3.0)
        self.velocity = pygame.Vector2(speed, 0).rotate(angle)

    def update(self):
        self.pos += self.velocity
        self.wrap_around_screen()
        self.rect.center = self.pos

    def wrap_around_screen(self):
        if self.pos.x < 0: self.pos.x = self.screen_width
        elif self.pos.x > self.screen_width: self.pos.x = 0
        if self.pos.y < 0: self.pos.y = self.screen_height
        elif self.pos.y > self.screen_height: self.pos.y = 0

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def split(self):
        new_asteroids = []
        size_map = {64: 48, 48: 32}
        if self.size in size_map:
            new_size = size_map[self.size]
            for _ in range(2):
                angle = random.uniform(0, 360)
                speed = random.uniform(1.0, 3.0)
                new_asteroid = Asteroid(
                    self.rect.centerx,
                    self.rect.centery,
                    new_size,
                    self.image_original,
                    self.screen_width,
                    self.screen_height
                )
                new_asteroid.velocity = pygame.Vector2(speed, 0).rotate(angle)
                new_asteroids.append(new_asteroid)
        return new_asteroids

    def get_collision_circle(self):
        return self.rect.center, self.rect.width // 2.5