import pygame
import math

class Player:
    def __init__(self, x, y, image):
        self.original_image = image
        self.image = image
        self.rect = self.image.get_rect(center=(x, y))
        self.pos = pygame.Vector2(x, y)
        self.angle = 0  # 0 degrees = facing up
        self.dx = 0
        self.dy = 0
        self.rotation_speed = 5
        self.thrust = 0.2
        self.friction = 0.98

    def update(self, keys, screen_width, screen_height):
        if keys[pygame.K_LEFT]:
            self.angle -= self.rotation_speed
        if keys[pygame.K_RIGHT]:
            self.angle += self.rotation_speed
        if keys[pygame.K_UP]:
            rad_angle = math.radians(self.angle)
            self.dx += math.sin(rad_angle) * self.thrust
            self.dy -= math.cos(rad_angle) * self.thrust

        self.dx *= self.friction
        self.dy *= self.friction

        self.pos.x += self.dx
        self.pos.y += self.dy

        self.wrap(screen_width, screen_height)

        self.image = pygame.transform.rotate(self.original_image, -self.angle)
        self.rect = self.image.get_rect(center=self.pos)

    def wrap(self, screen_width, screen_height):
        if self.pos.x < 0: self.pos.x = screen_width
        elif self.pos.x > screen_width: self.pos.x = 0
        if self.pos.y < 0: self.pos.y = screen_height
        elif self.pos.y > screen_height: self.pos.y = 0

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def get_angle(self):
        return self.angle

    def get_gun_position(self):
        return self.rect.center

    def get_collision_circle(self):
        return self.rect.center, self.rect.width // 2.5